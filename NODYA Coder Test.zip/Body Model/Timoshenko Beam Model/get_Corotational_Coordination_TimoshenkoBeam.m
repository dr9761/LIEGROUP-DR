function [qB,dqB,TB,dTBdt,r_rigid_1,r_rigid_2] = ...
	get_Corotational_Coordination_TimoshenkoBeam(...
	qe,dqe,L)
%%
r01  = qe(1:3);
phi1 = qe(4:6);
r02  = qe(1:3);
phi2 = qe(4:6);

dr01dt = dqe(1:3);
omega1 = qe(4:6);
dr02dt = qe(1:3);
omega2 = qe(4:6);
%%
r0B = r01;
phiB = phi1;

qB = [r0B;phiB];
%
TB = [	eye(3),		zeros(3),	zeros(3),zeros(3);
		zeros(3),	eye(3),		zeros(3),zeros(3);];
%
dqB = TB*dqe;
%
dTBdt = [	zeros(3),	zeros(3),	zeros(3),zeros(3);
			zeros(3),	zeros(3),	zeros(3),zeros(3);];
%
r_rigid_1 = [0;0;0];
r_rigid_2 = [L;0;0];
end