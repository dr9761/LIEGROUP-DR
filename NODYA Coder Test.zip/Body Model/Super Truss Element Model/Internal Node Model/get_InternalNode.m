function [qi,dqi,Ti,dTidt] = get_InternalNode(...
	qs,dqs,Ts,dTsdt,xi,BodyParameter)
%%
% [qi,dqi,T_i_s,dT_i_sdt] = ...
% 	get_InternalNode_Coordination_TimoshenkoBeam(...
% 	qs,dqs,xi,BodyParameter);
%
[qi,dqi,T_i_s,dT_i_sdt] = ...
	get_InternalNode_Coordination_CubicSplineBeam(...
	qs,dqs,xi,BodyParameter);
%%
Ti = T_i_s * Ts;
%%
dTidt = T_i_s * dTsdt + dT_i_sdt * Ts;
end









