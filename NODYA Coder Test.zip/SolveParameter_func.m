function SolveParameter_func(configs)
%% Change Working Dictionary
% fprintf('Welcome to use Rigid-Flexible Hybrid Multi-Body Dynamic Simulation Programm!\n');
% fprintf('\n');
% 
% FullPathOfProgramm = mfilename('fullpath'); 
% [FullPathOfProject,~]=fileparts(FullPathOfProgramm);
% CurrentWorkingDictionary = cd;
% if ~strcmp(CurrentWorkingDictionary,FullPathOfProject)
% 	fprintf('Your Current Working Dictionary is not the path of the Programm!\n');
% 	fprintf('In order to make the program run normally,\n');
% 	fprintf('Your Working Dictionary will be changed!\n');
% 	fprintf('...\n');
% % 	fprintf('Do you want to change your Working Dictionary?[Y/N]\n');
% 	cd(FullPathOfProject);
% 	fprintf('Working Dictionary has been changed!\n\n');
% end

%% Load Sub-Module
% Load_SubModule(FullPathOfProject);
%% Set Gravity
% g = Gravity_Configuration;
%% Load Parameter from Excel File
ExcelFileName = configs.ExcelFileName;
ExcelFileDir = configs.ExcelFileDir;
%
[ModelParameter,SolverParameter] = ...
	Set_AllParameter_from_ExcelFile(ExcelFileName,ExcelFileDir);
%
SolverParameter.ComputingDisplay.PlotMechanisum = false;
% InitalStateFigure = figure('Name','InitialState');
% InitalStateFigure = axes(InitalStateFigure);
% plot_Mechanism(ModelParameter.InitialState.q0, ...
% 	ModelParameter,SolverParameter,[]);
drawnow;
%%
AbsoluteTolerance = SolverParameter.ODE_Solver.AbsTol;
RelativeTolerance = SolverParameter.ODE_Solver.RelTol;
MaxStep = SolverParameter.ODE_Solver.MaxStep;
opt = odeset('RelTol',RelativeTolerance, ...
	'AbsTol',AbsoluteTolerance, ...
	'MaxStep',MaxStep, ...
	'OutputFcn',[]);
%%
SolverParameter.ActionFunction = configs.ActionFunctionHandle;
%% Static Position
tic;
Static_Start_Position = SolverParameter.StaticPosition.do_Calc;
max_VelocityAcceleration_Tolerance = ...
	SolverParameter.StaticPosition.max_Tol;
x0 = Calc_Static_Position(...
	Static_Start_Position,max_VelocityAcceleration_Tolerance, ...
	ModelParameter,SolverParameter,opt,[]);
%% dynamic ode
t_start = SolverParameter.ODE_Solver.t_start;
t_end = SolverParameter.ODE_Solver.t_end;
tspan = [t_start;t_end];
%
[t_set,x_set] = ode23tb(...
	@(t,x)Multi_Body_Dynamics_func(...
	t,x,tspan,ModelParameter,SolverParameter,[]), ...
	tspan,x0,opt);
%
SolvingTime = toc;
%% Save Result
SaveResult = SolverParameter.Result.SaveResult;
%
if SaveResult == true
	ResultFileAddress = ...
		['Result\',datestr(now,'yyyymmdd_HHMM'),ExcelFileName];
	mkdir(ResultFileAddress);
	ExcelFilePath = [ExcelFileDir,'\',ExcelFileName,'.xlsx'];
	copyfile(ExcelFilePath,ResultFileAddress);
	save([ResultFileAddress,'\Parameter.mat']);
	save([ResultFileAddress,'\OdeSetup.mat'],'opt','tspan');
	save([ResultFileAddress,'\Result.mat'], ...
		'x_set','t_set','SolvingTime');
end
%%
fprintf('Finished!\n');

end