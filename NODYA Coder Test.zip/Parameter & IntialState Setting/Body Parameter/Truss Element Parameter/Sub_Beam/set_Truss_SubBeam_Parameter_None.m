function SubBeamParameter = ...
	set_Truss_SubBeam_Parameter_None

SubBeamParameter.Beam = {};
SubBeamParameter.BeamLength = {};
SubBeamParameter.BodyParameter = {};
SubBeamParameter.Rotation = {};

end