function [SystemMass,SystemForce] = Baumgartner_Stability_MassForce(...
	Mass,Force, ...
	Phi,dPhi,B,Tau)
%%
alpha = 100;
beta = 1;
%%
lambda = (B' * inv(Mass) * B) \ ...
	(-B'*inv(Mass)*Force + ...
	Tau + 2*alpha*beta*dPhi + alpha^2*Phi);

SystemMass = Mass;
SystemForce = Force + B*lambda;
end