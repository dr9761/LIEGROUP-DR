clear;close all;
t1 = 2;
t2 = 6;
t3 = 2;
t0 = t1 + t2 + t3;
v0 = -pi/10;
dflag = 0;
s0 = v0*(1/2*t1+t2+1/2*t3)
v_set = [];
a_set = [];
s_set = [];
t_set = linspace(-0.2*(t1+t2+t3), ...
	1.2*(t1+t2+t3),1000);
for t = t_set
% 	[st,vt,at]=velocity_function_Test(t,t1,t2,t3,v0,dflag);
% 	[st,vt,at] = ThreeStage_PolyFunc(t,t1,t2,t3,v0);
	[st,vt,at] = ThreeStage_PolyFunc_2(t,s0,t0,t1,t3);
	v_set = [v_set,vt];
	a_set = [a_set,at];
	s_set = [s_set,st];
end
plot(t_set,s_set,'r-',t_set,v_set,'b-',t_set,a_set,'g-');
legend('s','v','a');

function [s,v,a]=velocity_function_Test(t,t1,t2,t3,v0,dflag)
%UNTITLED2 �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
if 0<=t && t<=t1
   v=v0*t^2*(3*t1-2*t)/t1^3;
   s=v0*t^3*(t1-1/2*t)/t1^3;
   a=6*v0*t*(t1-t)/t1^3;
end
if t1<t && t<t1+t2
   v=v0;
   s=1/2*v0*t1+v0*(t-t1);
   a=0; 
end
if t1+t2<=t && t<=t1+t2+t3
   v=v0*(t1+t2+t3-t)^2*(t3+2*t-2*t1-2*t2)/t3^3;
   s=1/2*v0*t1+v0*t2+v0*((t-t1-t2)-(t3*(t-t1-t2)^3-1/2*(t-t1-t2)^4)/t3^3);
   a=v0*6*(t1+t2-t)*(t1+t2+t3-t)/t3^3;
end

if dflag==1
 v=0;
 a=0;
 s=0;
end
end

