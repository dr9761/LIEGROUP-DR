function dx = Multi_Body_Dynamics_func(t,x,tspan, ...
	ModelParameter,SolverParameter, ...
	CalcPlotFigure)
%%
g = ModelParameter.g;
BodyElementParameter = ModelParameter.BodyElementParameter;
Frame_Joint_Parameter = ModelParameter.Frame_Joint_Parameter;
Joint_Parameter = ModelParameter.Joint_Parameter;
ConstraintParameter = ModelParameter.ConstraintParameter;
NodalForceParameter = ModelParameter.NodalForceParameter;
DriveParameter = ModelParameter.DriveParameter;
%%
% BodyElementParameter{16}.rho = 780/tspan(2)*t;
% BodyElementParameter{15}.L = BodyElementParameter{15}.L - ...
% 	10/tspan(2)*t;
%%
[Action,ActionTagSet] = get_Action(t,x,tspan,ModelParameter, ...
	SolverParameter.ActionFunction);
if DriveParameter.NodalForceDriveParameter.Drive_Action_Map.length ...
		~= numel(Action)
	Action = ...
		zeros(numel(DriveParameter),1);
	ActionTagSet = ...
		DriveParameter.NodalForceDriveParameter.Drive_Action_Map.keys;
	warning('Drive Parameter and Action do not match!');
% 	error('Drive Parameter and Action do not match!');
end
NodalForceParameter = apply_Action_to_NodalForceParameter(...
	DriveParameter,NodalForceParameter,Action,ActionTagSet);
% BodyElementParameter{9}.L = 4 + 2*t/10;
%%
q = x(1:numel(x)/2);
dq = x(numel(x)/2+1:end);
BodyQuantity = numel(BodyElementParameter);
%% Display Time
if SolverParameter.ComputingDisplay.DisplayTime
	fprintf('t = %16.14f\n',t);
end
%% Mechanisum Plot
persistent IterationNr;
if SolverParameter.ComputingDisplay.PlotMechanisum
	IterationNr = plot_Mechanisum_by_Computing(...
		q,t,ModelParameter,SolverParameter, ...
		CalcPlotFigure,IterationNr,tspan);
end
%%
Mass = sparse(numel(q),numel(q));
Force = sparse(numel(q),1);
%% Set Frame
q0  = zeros(6,1);
dq0 = zeros(6,1);
if t >= 0 && t <= 15
	% 	q0(5) = -pi/2 * 1/2*(1-cos(t*2*pi/10));
	% 	dq0(5) = -pi^2/20 * sin(t*2*pi/10);
	
	% 	[q0(5),dq0(5),~] = ...
	% 		ThreeStage_PolyFunc(t,9.5,0,0.5,-pi/10);
end
Frame.Joint = set_Frame_Joint(q0,dq0,Frame_Joint_Parameter);
Frame.T_qe_q = zeros(6,numel(q));
Frame.BodyType = 'Rigid Body';
%%
Body = cell(BodyQuantity,1);
for BodyNr = 1:BodyQuantity
	%%
	Body{BodyNr}.BodyType = ...
		BodyElementParameter{BodyNr}.BodyType;
	%%
	BodyCoordinate = ...
		BodyElementParameter{BodyNr}.GlobalCoordinate;
	
	qe  = q(BodyCoordinate);
	dqe = dq(BodyCoordinate);
	T_qe_q = zeros(numel(BodyCoordinate),numel(q));
	T_qe_q(:,BodyCoordinate) = eye(numel(BodyCoordinate));
	
	Body{BodyNr}.T_qe_q = T_qe_q;
	%%
	[Body{BodyNr}.Mass,Body{BodyNr}.Force] = get_Element_MassForce(...
		qe,dqe,g,BodyElementParameter{BodyNr});
	%%
	Body{BodyNr}.Joint = set_Joint(...
		qe,dqe,BodyElementParameter,BodyNr,Joint_Parameter);
	%%
	Mass(BodyCoordinate,BodyCoordinate) = ...
		Mass(BodyCoordinate,BodyCoordinate) + Body{BodyNr}.Mass;
	Force(BodyCoordinate) = ...
		Force(BodyCoordinate) + Body{BodyNr}.Force;
end
% for BodyNr = 1:BodyQuantity
% 	BodyCoordinate = BodyElementParameter{BodyNr}.GlobalCoordinate;
% 	
% 	Mass(BodyCoordinate,BodyCoordinate) = ...
% 		Mass(BodyCoordinate,BodyCoordinate) + Body{BodyNr}.Mass;
% 	Force(BodyCoordinate) = ...
% 		Force(BodyCoordinate) + Body{BodyNr}.Force;
% end
%% add static damping
StaticDampingFactor = 1;
if t < 0
	Force = Force + StaticDampingFactor * dq;
end
%%
% if t > 100 && t <= 110
% 	DampingFactor = 1;
% elseif t > 110
% 	DampingFactor = 0.01;
% else
% 	DampingFactor = 0;
% end
DampingFactor = 1;
Force = Force + DampingFactor * dq;
%% add Force Drive
if t >= 0
	Drive_Force = add_NodalForce(q,dq,t,Body,NodalForceParameter);
	Force = Force + Drive_Force;
end
%% add Constraint
[Phi,B,dPhi,Tau] = add_Constraint(q,dq,Frame,Body, ...
	BodyElementParameter,ConstraintParameter);
%% Baumgartner Stability Method
[ddq,~] = Baumgartner_Stability_Method(Mass,Force, ...
	Phi,dPhi,B,Tau);
%% get dqdt: Jaccobi Matrix between dqedt and dqe
dq_dt = get_dqdt(q,dq,BodyElementParameter);
%% dx
dx = [dq_dt;ddq];
end