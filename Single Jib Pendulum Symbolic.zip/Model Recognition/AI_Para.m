
clear all; close all; clc;
load('Result\Truss Parameter Test\Type 2\x-Axis Twist\Result.mat');
% addpath('D:\MA\MAformal\兵哥公式加程序\程序\Lattice Boom Test');
%% Change Working Dictionary
fprintf('Welcome to use Rigid-Flexible Hybrid Multi-Body Dynamic Simulation Programm!\n');
fprintf('\n');

FullPathOfProgramm = mfilename('fullpath');
[FullPathOfProject,~]=fileparts(fileparts(FullPathOfProgramm));
CurrentWorkingDictionary = cd;
if ~strcmp(CurrentWorkingDictionary,FullPathOfProject)
	fprintf('Your Current Working Dictionary is not the path of the Programm!\n');
	fprintf('In order to make the program run normally,\n');
	fprintf('Your Working Dictionary will be changed!\n');
	fprintf('...\n');
	% 	fprintf('Do you want to change your Working Dictionary?[Y/N]\n');
	cd(FullPathOfProject);
	fprintf('Working Dictionary has been changed!\n\n');
end
%% Load Sub-Module
Load_SubModule(FullPathOfProject);
%% Load Parameter from Excel File
ExcelFileName = ...
	'Lattice Type 2 Mass';
ExcelFileDir = [...
	'Parameter File', ...
	'\Lattice boom crane model\Lattice Parameterization'];
[ModelParameter,SolverParameter] = ...
	Set_AllParameter_from_ExcelFile(ExcelFileName,ExcelFileDir);
%%
stop_poi = 2000;
check_point = 100;
diff_t = diff(t_set(1:stop_poi));
diff_t(end+1) = diff_t(end);
ddqe_set = zeros(size(diff_t,1),12);
for i = 13:24
    diff_x = diff(x_set(1:stop_poi,i));
    diff_x(end+1) = diff_x(end);
    ddqe_set(:,i-12) = diff_x./diff_t;    
end

BodyParameter = ModelParameter.BodyElementParameter{1};

Theta = funclib(x_set(check_point,1:12)',x_set(check_point,13:24)',BodyParameter);


lambda = 1e-10;%0.0000000001; % very important!!!!0.0000001

% double Xi;
Xi = sparsifyDynamics(Theta, ddqe_set(check_point,:)', lambda, 1);  %or nx ok


dXdtau_pred = Theta*Xi;

e = sum(abs(dXdtau_pred - ddqe_set(check_point,:)'));
