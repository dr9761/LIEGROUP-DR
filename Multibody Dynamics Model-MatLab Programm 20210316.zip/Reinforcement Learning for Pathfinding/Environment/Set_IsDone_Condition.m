function IsDone = Set_IsDone_Condition(Obs,NextObs,Action)
%%
StateQuantity = numel(NextObs);
q = NextObs(1:StateQuantity/2);
dq = NextObs(StateQuantity/2+1:end);
%%
% rx = q(7);
% phi = q(4:6);
% gx = [1;0;0];
% gy = [0;1;0];
% gz = [0;0;1];
% nx = get_R(phi) * gx;
% 
% max_distance = 50;
% IsDone = abs(rx+1) > 20;
IsDone = false;

end