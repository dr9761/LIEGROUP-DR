function [q0,dq0,BodyElementParameter,ConstraintParameter] = ...
	Reduce_DegreeOfFreedom(...
	q0,dq0,BodyElementParameter,ConstraintParameter)
%%
fprintf('The degree of freedom will be reduced according to the constraints.\n');
fprintf('...\n');
ConstraintQuantity = numel(ConstraintParameter);
TotalCoordinateQuantity = numel(q0);
Abandon_ConstraintNrSet = [];
Abandon_StateVariableNrSet = [];
for ConstraintNr = 1:ConstraintQuantity
	ConstraintType = ConstraintParameter{ConstraintNr}.ConstraintType;
	BodyNr1 = ConstraintParameter{ConstraintNr}.BodyNr1;
	BodyNr2 = ConstraintParameter{ConstraintNr}.BodyNr2;
	
	JointNr1 = ConstraintParameter{ConstraintNr}.JointNr1;
	JointNr2 = ConstraintParameter{ConstraintNr}.JointNr2;
	if BodyNr1 == 0
		Body1 = [];
		BodyType1 = 'Frame';
	else
		Body1 = BodyElementParameter{BodyNr1};
		BodyType1 = Body1.BodyType;
	end
	if BodyNr2 == 0
		Body2 = [];
		BodyType2 = 'Frame';
	else
		Body2 = BodyElementParameter{BodyNr2};
		BodyType2 = Body2.BodyType;
	end
	%%
	[Coordinate_overlap,Coordinate_abandon, ...
		AbandonConstraintNr] = ...
		Reduce_DegreeOfFreedom_According_ConstraintType(...
		ConstraintType,ConstraintNr, ...
		Body1,Body2,BodyType1,BodyType2,JointNr1,JointNr2);
	
	Abandon_StateVariableNrSet = [Abandon_StateVariableNrSet, ...
		[Coordinate_overlap;Coordinate_abandon]];
	
	Abandon_ConstraintNrSet = ...
		[Abandon_ConstraintNrSet,AbandonConstraintNr];
	%%
% 	if ~strcmpi(BodyType1,'Rigid Body') && ...
% 			~strcmpi(BodyType2,'Rigid Body') && ...
% 			strcmpi(BodyType1,BodyType2)
% 		Coordinate1 = Body1.Coordinate;
% 		Coordinate2 = Body2.Coordinate;
% 		switch ConstraintType
% 			case 'Fixed'
% 				if JointNr1 == 1
% 					Joint1_Coordinate_overlap = Coordinate1(1:numel(Coordinate1)/2);
% 				elseif JointNr1 == 2
% 					Joint1_Coordinate_overlap = Coordinate1(numel(Coordinate1)/2+1:end);
% 				end
% 				if JointNr2 == 1
% 					Joint2_Coordinate_overlap = Coordinate2(1:numel(Coordinate2)/2);
% 				elseif JointNr2 == 2
% 					Joint2_Coordinate_overlap = Coordinate2(numel(Coordinate2)/2+1:end);
% 				end
% 				
% 				Coordinate_overlap = ...
% 					min(Joint1_Coordinate_overlap,Joint2_Coordinate_overlap);
% 				Coordinate_abandon = ...
% 					max(Joint1_Coordinate_overlap,Joint2_Coordinate_overlap);
% 				
% 				Abandon_StateVariableNrSet = [Abandon_StateVariableNrSet, ...
% 					[Coordinate_overlap;Coordinate_abandon]];
% 				
% 				Abandon_ConstraintNrSet = ...
% 					[Abandon_ConstraintNrSet,ConstraintNr];
% 			case 'Spherical'
% 				if strcmpi(BodyType1,'Strut Tie Model') || ...
% 						strcmpi(BodyType1,'Strut Tie Rope Model')
% 					if JointNr1 == 1
% 						Joint1_Coordinate_overlap = Coordinate1(1:numel(Coordinate1)/2);
% 					elseif JointNr1 == 2
% 						Joint1_Coordinate_overlap = Coordinate1(numel(Coordinate1)/2+1:end);
% 					end
% 					if JointNr2 == 1
% 						Joint2_Coordinate_overlap = Coordinate2(1:numel(Coordinate2)/2);
% 					elseif JointNr2 == 2
% 						Joint2_Coordinate_overlap = Coordinate2(numel(Coordinate2)/2+1:end);
% 					end
% 					
% 					Coordinate_overlap = ...
% 						min(Joint1_Coordinate_overlap,Joint2_Coordinate_overlap);
% 					Coordinate_abandon = ...
% 						max(Joint1_Coordinate_overlap,Joint2_Coordinate_overlap);
% 					
% 					Abandon_StateVariableNrSet = [Abandon_StateVariableNrSet, ...
% 						[Coordinate_overlap;Coordinate_abandon]];
% 					
% 					Abandon_ConstraintNrSet = ...
% 						[Abandon_ConstraintNrSet,ConstraintNr];
% 					
% 				end
% 		end
% 		
% 	end
end
%%
if ~isempty(Abandon_StateVariableNrSet)
	% delete abandoned Body Coordinate Number
	BodyElementParameter = ...
		Delete_Abandoned_BodyCoordinate(...
		BodyElementParameter,TotalCoordinateQuantity, ...
		Abandon_StateVariableNrSet);
	% delete abandoned State Variable
	[q0,dq0] = Delete_Abandoned_StateVariable(...
		q0,dq0,TotalCoordinateQuantity, ...
		Abandon_StateVariableNrSet);
	%
	fprintf('Degree of Freedom: From %d to %d,\tsaving %4.2f%%\n', ...
		TotalCoordinateQuantity,numel(q0), ...
		100*(1-numel(q0)/TotalCoordinateQuantity));
end

%% delete abandoned Constraint
if ~isempty(Abandon_ConstraintNrSet)
	PreviousConstraintQuantity = numel(ConstraintParameter);
	ConstraintParameter(Abandon_ConstraintNrSet) = [];
	CurrentConstraintQuantity = numel(ConstraintParameter);
	%
	fprintf('Constraint:        From %d to %d,\tsaving %4.2f%%\n', ...
		PreviousConstraintQuantity,CurrentConstraintQuantity, ...
		100*(1-CurrentConstraintQuantity/PreviousConstraintQuantity));
end

%%
fprintf('Reduction has been completed!\n\n');
end