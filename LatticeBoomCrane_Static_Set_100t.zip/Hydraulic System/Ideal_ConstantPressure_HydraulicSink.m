function [p,Q] = Ideal_ConstantPressure_HydraulicSink(pb)

p = pb;
Q = -Inf;

end