function [dx,Mass,Force,lambda] = Multi_Body_Dynamics_Symbolic_func(...
	t,x,u,ModelParameter)
%%
g = ModelParameter.g;
BodyElementParameter = ModelParameter.BodyElementParameter;
Frame_Joint_Parameter = ModelParameter.Frame_Joint_Parameter;
Joint_Parameter = ModelParameter.Joint_Parameter;
ConstraintParameter = ModelParameter.ConstraintParameter;
NodalForceParameter = ModelParameter.NodalForceParameter;
DriveParameter = ModelParameter.DriveParameter;
%%
Action = u;
ActionTagSet = ...
	DriveParameter.NodalForceDriveParameter.Drive_Action_Map.keys;
NodalForceParameter = apply_Action_to_NodalForceParameter_Symbolic(...
	DriveParameter,NodalForceParameter,Action,ActionTagSet);
%%
q = x(1:numel(x)/2);
dq = x(numel(x)/2+1:end);
BodyQuantity = numel(BodyElementParameter);
%% Set Frame
q0  = casadi.SX.zeros(6,1);
dq0 = casadi.SX.zeros(6,1);
Frame.Joint = set_Frame_Joint_Symbolic(q0,dq0,Frame_Joint_Parameter);
Frame.T_qe_q = casadi.SX.zeros(6,numel(q));
Frame.BodyType = 'Rigid Body';
%%
Mass = casadi.SX.zeros(numel(q),numel(q));
Force = casadi.SX.zeros(numel(q),1);
%%
Body = cell(BodyQuantity,1);
fprintf('\tCalculate the Sybolic Mass & Force of Bodies:\n');
for BodyNr = 1:BodyQuantity
	%%
	Body{BodyNr}.BodyType = ...
		BodyElementParameter{BodyNr}.BodyType;
	%%
	BodyCoordinate = BodyElementParameter{BodyNr}.GlobalCoordinate;
	
	qe  = q(BodyCoordinate);
	dqe = dq(BodyCoordinate);
	T_qe_q = zeros(numel(BodyCoordinate),numel(q));
	T_qe_q(:,BodyCoordinate) = eye(numel(BodyCoordinate));
	
	Body{BodyNr}.T_qe_q = T_qe_q;
	%%
	[Body{BodyNr}.Mass,Body{BodyNr}.Force] = ...
		get_Element_MassForce_Symbolic(...
		qe,dqe,g,BodyElementParameter{BodyNr});
	%%
	Body{BodyNr}.Joint = set_Joint_Symbolic(...
		qe,dqe,BodyElementParameter,BodyNr,Joint_Parameter);
	%%
	Mass(BodyCoordinate,BodyCoordinate) = ...
		Mass(BodyCoordinate,BodyCoordinate) + Body{BodyNr}.Mass;
	Force(BodyCoordinate) = ...
		Force(BodyCoordinate) + Body{BodyNr}.Force;
	%%
	fprintf('\t\tBody %3.0f finished!\n',BodyNr);
end
%% add Force Drive
Drive_Force = add_NodalForce_Symbolic(q,dq,t,Body,NodalForceParameter);
Force = Force + Drive_Force;
fprintf('\tSymbolic Nodal Force applied!\n');
%% add Constraint
[Phi,B,dPhi,Tau] = add_Constraint_Symbolic(q,dq,Frame,Body, ...
	BodyElementParameter,ConstraintParameter);
fprintf('\tSymbolic Constraints finished!\n');
%% Baumgartner Stability Method
[SystemMass,SystemForce,lambda] = ...
	Baumgartner_Stability_MassForce(...
	Mass,Force,Phi,dPhi,B,Tau);
fprintf('\tSymbolic System Mass & Force finished!\n');
ddq = -SystemMass \ SystemForce;
%
fprintf('\tGeneralized Acceleration finished!\n');
% [ddq,~] = Baumgartner_Stability_Method(Mass,Force, ...
% 	Phi,dPhi,B,Tau);
%% get dqdt: Jaccobi Matrix between dqedt and dqe
dq_dt = get_dqdt_Symbolic(q,dq,BodyElementParameter);
%% dx
dx = [dq_dt;ddq];
fprintf('\tFirst derivative of state variable finished!\n');
end