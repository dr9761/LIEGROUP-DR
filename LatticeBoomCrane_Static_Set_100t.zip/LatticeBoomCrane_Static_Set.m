clc;clear;
close all;
%% Change Working Dictionary
Welcome_to_Programm;
%% Configure Working Directory
FullPathOfProject = Configure_WorkingDirectory;
%% Load Sub-Module
Load_SubModule(FullPathOfProject);
%% Load Parameter from Excel File
ExcelFileName = ...
	'100t';
ExcelFileDir = [...
	'Parameter File', ...
	'\Lattice boom crane model', ...
	'\Truss Equivalent Model', ...
	'\Load in Air'];
%%
[ModelParameter,SolverParameter] = ...
	Set_AllParameter_from_ExcelFile(ExcelFileName,ExcelFileDir);
%% Action Function
SolverParameter.ActionFunction = get_ActionFunction('None');
%% plot Initial State
do_plot_InitialState = true;
InitalStateAxes = plot_InitialState(do_plot_InitialState, ...
	ModelParameter,SolverParameter);

%% Static Position
tic;
%% Statics
do_Statics_Calculation = true;
pos_static = cell(41,32);
if do_Statics_Calculation
	for MainBoomAngleNr = 1:2 % 1:41
		MainBoomAngle = MainBoomAngleNr - 1 + 45;
% 		delta_L13 = (delta_L13_Nr-1)*0.1;
% 		delta_L13 = (delta_L13_Nr-1)*2;
		pos_static_temp = cell(1,32);
		for deltaLNr = 1:2 % 1:32
% 			delta_L15 = (delta_L15_Nr-1)*0.1;
			deltaL = deltaLNr - 1;
			[ModelParameter2] = Calc_LatticeBoomCrane_InitialCoordinate(...
				MainBoomAngle,deltaL,ModelParameter);
			
			q0 = ModelParameter2.InitialState.q0;
			SystemForceFcn = @(q)Multi_Body_Dynamics_Force(q,[0,1], ...
				ModelParameter2,SolverParameter);
			%
			fsolve_PlotFcn_Handle = ...
				@(x,optimValues,state,varargin)optimplot_Mechanism(...
				x,optimValues,state,varargin, ...
				ModelParameter2,SolverParameter);
			opt = optimoptions('fsolve', ...
				'Algorithm','trust-region', ...
				'StepTolerance',1e-12, ...
				'FunctionTolerance',1e-12, ...
				'SpecifyObjectiveGradient',false, ...
				'Display','iter', ...
				'MaxIterations',1000, ...
				'MaxFunctionEvaluations',2000000, ...
				'PlotFcn',[]);
			[q_Static,Force_Static,StaticFlag,output,jacobian] = ...
				fsolve(SystemForceFcn,q0,opt);
			StaticError = SystemForceFcn(q_Static);
			MaxAbsStaticError=max(abs(StaticError));
			%
			dq_Static = zeros(size(q_Static));
			x_Static = [q_Static;dq_Static];
			x0 = x_Static;
			dx0 = Multi_Body_Dynamics_func(deltaLNr,x0,[0,1], ...
				ModelParameter2,SolverParameter,[]);
			%
			pos_static_temp{deltaLNr} = q_Static;
% 			pos_static{MainBoomAngleNr,deltaLNr} = q_Static([115,117]);
			% 	plot_Mechanism(q_Static, ...
			% 		ModelParameter,SolverParameter,InitalStateAxes);
			fprintf('%d/%d finished:%d/%d!\n', ...
				MainBoomAngleNr,deltaLNr, ...
				pos_static_temp{deltaLNr}(115),pos_static_temp{deltaLNr}(117));
		end
		for deltaLNr = 1:32
			pos_static{MainBoomAngleNr,deltaLNr} = pos_static_temp{deltaLNr};
		end
	end
end
