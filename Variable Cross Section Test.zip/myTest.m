function myTest

myTestFigure = figure('Name','myTestFigure');
myTestAxes = axes(myTestFigure);

plot(myTestAxes,1:10,sin(1:10));

end