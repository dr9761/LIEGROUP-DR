function [SystemMass,SystemForce] = ...
	Multi_Body_Dynamics_MassForce(t,x,tspan,ModelParameter, ...
	useConstraint)
%%
g = ModelParameter.g;
BodyElementParameter = ModelParameter.BodyElementParameter;
Frame_Joint_Parameter = ModelParameter.Frame_Joint_Parameter;
Joint_Parameter = ModelParameter.Joint_Parameter;
ConstraintParameter = ModelParameter.ConstraintParameter;
NodalForceParameter = ModelParameter.NodalForceParameter;
DriveParameter = ModelParameter.DriveParameter;
%
[Action,ActionTagSet] = get_Action(t,x,tspan,ModelParameter);
if DriveParameter.NodalForceDriveParameter.Drive_Action_Map.length ...
		~= numel(Action)
	Action = ...
		zeros(numel(DriveParameter),1);
	ActionTagSet = ...
		DriveParameter.NodalForceDriveParameter.Drive_Action_Map.keys;
	warning('Drive Parameter and Action do not match!');
	% 	error('Drive Parameter and Action do not match!');
end
NodalForceParameter = apply_Action_to_NodalForceParameter(...
	DriveParameter,NodalForceParameter,Action,ActionTagSet);
% BodyElementParameter{9}.L = 4 + 2*t/10;
%%
q = x(1:numel(x)/2);
dq = x(numel(x)/2+1:end);
BodyQuantity = numel(BodyElementParameter);
%%
Mass = zeros(numel(q),numel(q));
Force = zeros(numel(q),1);
%%
%% Set Frame
q0  = zeros(6,1);
dq0 = zeros(6,1);
if t >= 0 && t <= 15
	% 	q0(5) = -pi/2 * 1/2*(1-cos(t*2*pi/10));
	% 	dq0(5) = -pi^2/20 * sin(t*2*pi/10);
	
	% 	[q0(5),dq0(5),~] = ...
	% 		ThreeStage_PolyFunc(t,9.5,0,0.5,-pi/10);
end
Frame.Joint = set_Frame_Joint(q0,dq0,Frame_Joint_Parameter);
Frame.T_qe_q = zeros(6,numel(q));
Frame.BodyType = 'Rigid Body';
%%
Body = cell(BodyQuantity,1);
for BodyNr = 1:BodyQuantity
	%%
	Body{BodyNr}.BodyType = ...
		BodyElementParameter{BodyNr}.BodyType;
	%%
	BodyCoordinate = BodyElementParameter{BodyNr}.Coordinate;
	
	qe  = q(BodyCoordinate);
	dqe = dq(BodyCoordinate);
	T_qe_q = zeros(numel(BodyCoordinate),numel(q));
	T_qe_q(:,BodyCoordinate) = eye(numel(BodyCoordinate));
	
	Body{BodyNr}.T_qe_q = T_qe_q;
	%%
	[Body{BodyNr}.Mass,Body{BodyNr}.Force] = get_Element_MassForce(...
		qe,dqe,g,BodyElementParameter{BodyNr});
	%%
	Body{BodyNr}.Joint = set_Joint(...
		qe,dqe,BodyElementParameter,BodyNr,Joint_Parameter);
	%%
	Mass(BodyCoordinate,BodyCoordinate) = ...
		Mass(BodyCoordinate,BodyCoordinate) + Body{BodyNr}.Mass;
	Force(BodyCoordinate) = ...
		Force(BodyCoordinate) + Body{BodyNr}.Force;
end
%% add static damping
StaticDampingFactor = 1;
if t < 0
	Force = Force + StaticDampingFactor * dq;
end
%%
% if t > 100 && t <= 110
% 	DampingFactor = 1;
% elseif t > 110
% 	DampingFactor = 0.01;
% else
% 	DampingFactor = 0;
% end
DampingFactor = 0;
Force = Force + DampingFactor * dq;
%% add Force Drive
if t >= 0
	Drive_Force = add_NodalForce(q,dq,t,Body,NodalForceParameter);
	Force = Force + Drive_Force;
end
%%
SystemMass = Mass;
SystemForce = Force;
%% apply Constriant
if useConstraint
	%% add Constraint
	[Phi,B,dPhi,Tau] = add_Constraint(q,dq,Frame,Body, ...
		BodyElementParameter,ConstraintParameter);
	%% Baumgartner Stability Method
	[SystemMass,SystemForce] = Baumgartner_Stability_MassForce(...
		Mass,Force, ...
		Phi,dPhi,B,Tau);
end
end