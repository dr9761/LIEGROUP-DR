% VariableCrossSection_CubicSpline_DynamicRecognition_Test
%%
clc;clear;close all;
ExcelFileName = ...
	'Cubic Spline Beam - 5 Segments';
ExcelFileDir = [...
	'Parameter File', ...
	'\Variable cross-section continuous beam'];
[ModelParameter,SolverParameter] = ...
	Set_AllParameter_from_ExcelFile(ExcelFileName,ExcelFileDir);
SolverParameter.ActionFunction = get_ActionFunction('None');
%%
qe = ModelParameter.InitialState.q0;
dqe = ModelParameter.InitialState.dq0;
t = 0;
x = [qe;dqe];
tspan = [0;1];
g = ModelParameter.g;
BodyParameter = ModelParameter.BodyElementParameter{1};
% [Mass,Force] = Super_Truss_Element_MassForce(...
% 	qe,dqe,g,BodyParameter);
CalcPlotFigure = [];

dx = Multi_Body_Dynamics_func(t,x,tspan, ...
	ModelParameter,SolverParameter, ...
	CalcPlotFigure);
ddq = dx(numel(dx)/2+1:end);
ddq_end = [ddq(1:7);ddq(end-6:end)];
%%
% BodyParameter.L = BodyParameter.Truss_Parameter.TrussLength;
qs = [qe(1:7);qe(end-6:end)];
dqs = [dqe(1:7);dqe(end-6:end)];
gaussn = 11;
[ddqe_Function_Library] = ...
	CubicSpline_Dynamic_FunctionLibrary(...
	qs,dqs,g,BodyParameter,gaussn);
%% Mass
StateDimension = numel(qe);
lambda = 1e-6;
FunctionOutput = Mass;
FunctionLibrary = CubicSpline_Mass_Function_Library;
Xi = sparsifyDynamics(FunctionLibrary,FunctionOutput,lambda,StateDimension);
%
FunctionOutput_Predictive = FunctionLibrary*Xi;
if size(FunctionOutput,2) == 1
	Predictive_Error = sum(abs(FunctionOutput_Predictive - FunctionOutput));
else
	Predictive_Error = sum(sum(abs(FunctionOutput_Predictive - FunctionOutput)));
end
%% Force
StateDimension = 1;
lambda = 1e-6;
FunctionOutput = Force;
FunctionLibrary = CubicSpline_Force_Function_Library;
Xi = sparsifyDynamics(FunctionLibrary,FunctionOutput,lambda,StateDimension);
%
FunctionOutput_Predictive = FunctionLibrary*Xi;
if size(FunctionOutput,2) == 1
	Predictive_Error = sum(abs(FunctionOutput_Predictive - FunctionOutput));
else
	Predictive_Error = sum(sum(abs(FunctionOutput_Predictive - FunctionOutput)));
end