clc;clear;
close all;
%%
ExcelFileName = ...
	'Shrink Super Truss Element Pendulum Test';
ExcelFileDir = [...
	'Parameter File\Pendulum Test', ...
	'\Super Truss Element Pendulum Test'];

[ModelParameter,SolverParameter] = ...
	Set_AllParameter_from_ExcelFile(ExcelFileName,ExcelFileDir);
BodyParameter = ModelParameter.BodyElementParameter{1};
%%
qe = casadi.SX.sym('q',12,1);
dqe = casadi.SX.sym('dq',12,1);
g = ModelParameter.g;
[Mass,Force] = Super_Truss_Element_MassForce_Symbolic(...
	qe,dqe,g,BodyParameter);
SuperTrussElement_MassForce_Func = ...
	casadi.Function('SuperTrussElement_MassForce_JacobianFunc', ...
	{qe,dqe}, {Mass, Force}, ...
	{'qe','dqe'}, {'Mass','Force'});
%%
L = BodyParameter.Truss_Parameter.TrussLength;
r01 = [0;0;0];phi1 = [0;0;0];q1 = [r01;phi1];
r02 = [L;0;0];phi2 = [0;0;0];q2 = [r02;phi2];
qe = [q1;q2];

dr01dt = [0;0;0];omega1 = [0;0;0];dq1 = [dr01dt;omega1];
dr02dt = [0;0;0];omega2 = [0;0;0];dq2 = [dr02dt;omega2];
dqe = [dq1;dq2];
%%
tic;
SuperTrussElement_MassForce = ...
	SuperTrussElement_MassForce_Func(...
	'qe',qe,'dqe',dqe);
Mass_1 = ...
	full(SuperTrussElement_MassForce.Mass);
Force_1 = ...
	full(SuperTrussElement_MassForce.Force);
toc;
%%
tic;
[Mass_2,Force_2] = Super_Truss_Element_MassForce(...
	qe,dqe,g,BodyParameter);
toc;
%%
Mass_1(Mass_1==0) = eps;
Mass_2(Mass_2==0) = eps;
deltaMass = Mass_1 - Mass_2;
f_rel_Mass_1 = deltaMass ./ Mass_1;f_rel_Mass_1(ismissing(f_rel_Mass_1)) = 0;
f_rel_Mass_2 = deltaMass ./ Mass_2;f_rel_Mass_2(ismissing(f_rel_Mass_2)) = 0;
e_Mass = (f_rel_Mass_1.^2 + f_rel_Mass_2.^2) .* max(abs(Mass_1),abs(Mass_2));
sum(sum(e_Mass))
deltaForce = Force_1 - Force_2;