function [p,Q] = Ideal_ConstantPressure_HydraulicPump(ps)

p = ps;
Q = Inf;

end