function [CrossSectionBeamMass,CrossSectionBeamForce] = ...
	get_CrossSectionBeam_Mass_Force_Symbolic(...
	CrossSectionNr,BeamNr,Point1Nr,Point2Nr,Body_Parameter, ...
	CrossSectionBeamParameter,CrossSectionNode,dqe,g)
%%
phib = ...
	CrossSectionBeamParameter.CrossSectionBeam{CrossSectionNr}.Rotation{BeamNr};
Rdb = get_R(phib);
T_b_cs = [eye(3),zeros(3);zeros(3),Rdb'];
%%
q1 = CrossSectionNode.CrossSection{CrossSectionNr}.qs{Point1Nr};
q2 = CrossSectionNode.CrossSection{CrossSectionNr}.qs{Point2Nr};

r01 = q1(1:3);
r02 = q2(1:3);
r0b = [r01;r02];

phi1 = q1(4:6);
phi2 = q2(4:6);
R1 = get_R_Symbolic(phi1);
R2 = get_R_Symbolic(phi2);
Rb = [R1;R2];
%%
dq1 = CrossSectionNode.CrossSection{CrossSectionNr}.dqs{Point1Nr};
dq2 = CrossSectionNode.CrossSection{CrossSectionNr}.dqs{Point2Nr};

dqb1 = casadi.SX.zeros(6,1);
dqb1(1:3) = dq1(1:3);
dqb1(4:6) = Rdb' * dq1(4:6);

dqb2 = casadi.SX.zeros(6,1);
dqb2(1:3) = dq2(1:3);
dqb2(4:6) = Rdb' * dq2(4:6);

dqb = [dqb1;dqb2];
%%
Tcs1 = CrossSectionNode.CrossSection{CrossSectionNr}.Ts{Point1Nr};
Tcs2 = CrossSectionNode.CrossSection{CrossSectionNr}.Ts{Point2Nr};

Tb1 = T_b_cs * Tcs1;
Tb2 = T_b_cs * Tcs2;

Tb = [Tb1;Tb2];
%%
dTcs1dt = CrossSectionNode.CrossSection{CrossSectionNr}.dTs{Point1Nr};
dTcs2dt = CrossSectionNode.CrossSection{CrossSectionNr}.dTs{Point2Nr};

dTb1dt = T_b_cs * dTcs1dt;
dTb2dt = T_b_cs * dTcs2dt;

dTbdt = [dTb1dt;dTb2dt];
%%
[CrossSectionBeamMass,CrossSectionBeamForce] = ...
	SuperTrussElement_TimoshenkoBeam_MassForce_Symbolic(...
	r0b,Rb,dqb,g,Body_Parameter);
%%
CrossSectionBeamForce = Tb' * (CrossSectionBeamMass * dTbdt * dqe + ...
	CrossSectionBeamForce);
CrossSectionBeamMass = Tb' * CrossSectionBeamMass * Tb;


end