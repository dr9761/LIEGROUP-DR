function Welcome_to_Programm

fprintf(['Welcome to use ', ...
	'Rigid-Flexible Hybrid Multi-Body Dynamic Simulation Programm!', ...
	'\n']);
fprintf('\n');


end