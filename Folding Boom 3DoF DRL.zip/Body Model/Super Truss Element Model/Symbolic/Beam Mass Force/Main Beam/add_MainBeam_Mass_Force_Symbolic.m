function [MainBeamMass,MainBeamForce] = ...
	add_MainBeam_Mass_Force_Symbolic(...
	InternalNode,MainBeamParameter,dqe,g)
%%
MainBeamMass  = casadi.SX.zeros(12,12);
MainBeamForce = casadi.SX.zeros(12,1);
%%
TrussOrder = size(InternalNode.Plane{1}.r0i,2)-1;
%%
MainBeamQuantity = numel(MainBeamParameter.Beam);
MainBeamLengthSet = MainBeamParameter.BeamLength;
MainBeamBodyParameterSet = MainBeamParameter.BodyParameter;
for MainBeamNr = 1:MainBeamQuantity
	L = MainBeamLengthSet{MainBeamNr};
	Li = L / TrussOrder;
	%%
	Body_Parameter = MainBeamBodyParameterSet{MainBeamNr};
	Body_Parameter.L = Li;
	%%
	[MainBeamMass,MainBeamForce] = ...
		get_MainBeam_MassForce_of_one_MainBeam_Symbolic(...
		dqe,g,TrussOrder,MainBeamNr, ...
		InternalNode,MainBeamParameter,Body_Parameter, ...
		MainBeamMass,MainBeamForce);
end

end