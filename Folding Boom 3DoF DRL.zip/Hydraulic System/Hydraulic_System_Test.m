%% Hydraulic_System_Test
clear;clc;close all;
%%
x = zeros(10,1);
x(7:10) = [3e7;1.5e6;3e7;1.5e6]/1e6;
u = 1*[0;1;1];
%%
ExcelFilePath = 'Parameter File\Hydraulic System Test\Hydraulic System Test - 2.xlsx';

[HydraulicOilParameter,HydraulicElementParameter,HydraulicCoordinateQuantity] = ...
	create_HydraulicElement(ExcelFilePath);

HydraulicConnectionParameter = create_HydraulicConnection(ExcelFilePath);

HydraulicSymbolicStateSolution = create_HydraulicCalculationEquation(...
	HydraulicOilParameter,HydraulicElementParameter,HydraulicCoordinateQuantity, ...
	HydraulicConnectionParameter);

%%
HydraulicParameter.HydraulicEquation = HydraulicSymbolicStateSolution;
% HydraulicParameter.PressureFlowIndex = PressureFlowIndex;
HydraulicParameter.HydraulicElementParameter = HydraulicElementParameter;
HydraulicParameter.HydraulicOilParameter = HydraulicOilParameter;
%
HydraulicElementState = solve_HydraulicCalculationEquatition(...
	x,u,HydraulicSymbolicStateSolution);

[HydraulicElementState(3,3);HydraulicElementState(3,4); ...
	HydraulicElementState(8,3);HydraulicElementState(8,4)]