function [q0,dq0,x,ModelParameter] = ModelPreProcessing(PreProcessingMethode, ...
	t,x,tspan,ModelParameter)
%%
switch PreProcessingMethode
	case 'None'
		q0  = zeros(6,1);
		dq0 = zeros(6,1);
	case 'Cantilever Pendulum Frame Motion'
		s0 = -pi/2;
		t0 = tspan(2) - tspan(1);
		t1 = 0.1 * t0;
		t3 = 0.1 * t0;
		[s,v,a] = ThreeStage_PolyFunc_2(t,s0,t0,t1,t3);
		q0  = zeros(6,1);
		q0(5) = s;
		dq0 = zeros(6,1);
		dq0(5) = v;
	otherwise
		q0  = zeros(6,1);
		dq0 = zeros(6,1);
end


end