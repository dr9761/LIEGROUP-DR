function [Action,ActionTagSet] = get_Action_None(...
	t,x,tspan,ModelParameter)

Action = [];
ActionTagSet = {};

end