function [Action,ActionTagSet] = get_Action_FoldingBoom(...
	t,x,tspan,ModelParameter)

Action = [-1e6;-1e6];
ActionTagSet = {'UnderAct';'AboveAct'};

end